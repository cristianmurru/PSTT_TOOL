select *
from t_tt2_operatore tto
where tto.sistema ='PTL'
