"""
PSTT Tool - Strumento per l'esecuzione di query parametrizzate su database multi-vendor
"""

__version__ = "1.0.0"
__author__ = "PSTT Development Team"
__description__ = "Tool per query parametrizzate con scheduling automatico"
