select * from starown.po_causali order by caunotif
