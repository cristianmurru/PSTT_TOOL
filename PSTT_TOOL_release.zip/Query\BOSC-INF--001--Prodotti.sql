--Visualizza elenco prodotti

select * from tt_application.product

