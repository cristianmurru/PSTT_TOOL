select  * from starown.po_causali_delreason order by delreason
